# CS3030_FinalProject
Final project, includes scripting languages such as Perl and Golang 


###Perl: The main script
This script is very similar to the fredData bash script.
It contains some subroutines that mimic the behaviour of the bash script.
The usage sunroutine (Helper) should take care of how to use the script.


###Go: Second script
Does the same job but using golang. It has some functions that are the same
as the ones in Perl, and everything is called in main.
USE THE COMPILED FILE.
